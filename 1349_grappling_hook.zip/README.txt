v1.3.6

Installation, hotkeys and all info needed you will find at the following blog post:
http://gtaxscripting.blogspot.com/2015/05/gta-v-just-cause-2-grappling-hook-mod.html

Please don't reupload my mods

Copyright � 2015 by GTA5Base.com and TJulioNIB

All rights reserved. No part of this Mod may be reuploaded to any other site/hosting/server. 
GTA5Base has exclusive rights to publish this Mod.

In case of violation of these terms, there will be taken appropriate legal procedures.

Global Modding Community S.C. Kopec, Ogorek
90-640, Poland, Lodz
28 Pulku Strzelcow Kaniowskich 42
www.GTA5Base.com